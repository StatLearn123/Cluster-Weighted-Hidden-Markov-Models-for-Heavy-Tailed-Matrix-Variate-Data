#' @title Random Generation for Matrix-Variate Hidden Markov Cluster-Weighted Models
#'
#' @description Generates random samples from a Matrix-Variate Hidden Markov Cluster-Weighted Model
#' allowing independent specification of the distribution for covariates (X) and response (Y).
#' Both components can follow Matrix-Variate Normal (MVN), Matrix-Variate t (MVT),
#' or Matrix-Variate Contaminated Normal (MVCN) distributions.
#'
#' @param density.X Character string specifying the distribution for covariates X.
#' Options are \code{"MVN"}, \code{"MVT"}, or \code{"MVCN"}. Default is \code{"MVN"}.
#'
#' @param density.Y Character string specifying the distribution for response Y.
#' Options are \code{"MVN"}, \code{"MVT"}, or \code{"MVCN"}. Default is \code{"MVN"}.
#'
#' @param num Integer. The number of units to simulate.
#' @param t Integer. The length of the time series (number of time points).
#' @param PI A matrix of dimension \code{k x k} representing the transition probability matrix
#' of the hidden Markov chain.
#' @param M An array of dimension \code{q x r x k} containing the mean matrices
#' of the covariates (X) for each state.
#' @param B An array of dimension \code{p x (q + 1) x k} containing the regression
#' coefficient matrices for each state (including the intercept).
#' @param U.Y An array of dimension \code{p x p x k} containing row covariance/scale matrices for Y.
#' @param V.Y An array of dimension \code{r x r x k} containing column covariance/scale matrices for Y.
#' @param U.X An array of dimension \code{q x q x k} containing row covariance/scale matrices for X.
#' @param V.X An array of dimension \code{r x r x k} containing column covariance/scale matrices for X.
#' @param IP A numeric vector of length \code{k} specifying the initial probabilities of the hidden states.
#'
#' @param nu.X A numeric vector of length \code{k} specifying degrees of freedom for X (used if \code{density.X = "MVT"}).
#' @param nu.Y A numeric vector of length \code{k} specifying degrees of freedom for Y (used if \code{density.Y = "MVT"}).
#'
#' @param alpha.X A numeric vector of length \code{k} specifying proportion of typical observations for X
#' (used if \code{density.X = "MVCN"}).
#' @param alpha.Y A numeric vector of length \code{k} specifying proportion of typical observations for Y
#' (used if \code{density.Y = "MVCN"}).
#'
#' @param eta.X A numeric vector of length \code{k} specifying variance inflation factors for X
#' (used if \code{density.X = "MVCN"}).
#' @param eta.Y A numeric vector of length \code{k} specifying variance inflation factors for Y
#' (used if \code{density.Y = "MVCN"}).
#'
#' @param seed Optional integer setting the random number generator state.
#'
#' @return A list containing:
#' \itemize{
#'   \item \code{Y}: array \code{p x r x num x t} of simulated responses.
#'   \item \code{X}: array \code{q x r x num x t} of simulated covariates.
#'   \item \code{obs.states}: matrix \code{num x t} of hidden states.
#'   \item \code{pgood.X}: (if \code{density.X = "MVCN"}) indicator matrix of good/bad X observations.
#'   \item \code{pgood.Y}: (if \code{density.Y = "MVCN"}) indicator matrix of good/bad Y observations.
#' }
#'
#' @importFrom stats rmultinom rgamma rbinom runif
#' @importFrom LaplacesDemon rmatrixnorm
#' @importFrom withr with_seed
#'
#' @export
rHMCWMHT <- function(density.X = "MVN", density.Y = "MVN", num, t, PI, M, B,
                     U.Y, V.Y, U.X, V.X, IP,
                     nu.X = NULL, nu.Y = NULL,
                     alpha.X = NULL, alpha.Y = NULL,
                     eta.X = NULL, eta.Y = NULL,
                     seed = NULL) {

  # ---- 1. Funzioni Interne di Supporto ----
  run.mc.sim <- function(P, times, IP) {

    num.states <- nrow(P)
    states <- numeric(times)
    k <- length(IP)

    states[1] <- sample(1:k, size = 1, prob = IP)

    for (t in 2:times) {
      p <- P[states[t - 1], ]
      states[t] <- which(rmultinom(1, 1, p) == 1)
    }
    return(states)
  }

  rTMV <- function(n, M, U, V, nu) {
    w <- stats::rgamma(n = n, nu / 2, nu / 2)
    X <- array(0, dim = c(nrow(M), ncol(M), n))

    for (i in 1:n) {
      X[, , i] <- LaplacesDemon::rmatrixnorm(M = M, U = U / w[i], V = V)
    }

    return(X)
  }

  # ---- 2. Setup Dimensioni e Inizializzazione ----
  row.Y <- dim(U.Y)[1]
  col.Y <- dim(V.Y)[2]
  row.X <- dim(U.X)[1]
  col.X <- dim(V.X)[2]
  k <- nrow(PI)

  Y <- array(NA, dim = c(row.Y, col.Y, num, t))
  X <- array(NA, dim = c(row.X, col.X, num, t))

  good.X <- if(density.X == "MVCN") matrix(NA, num, ncol = t) else NULL
  good.Y <- if(density.Y == "MVCN") matrix(NA, num, ncol = t) else NULL

  chain.states <- matrix(NA, ncol = num, nrow = t)

  for (c in seq_len(num)) {
    chain.states[, c] <- run.mc.sim(PI, t, IP = IP)
  }

  if (is.null(seed)) {
    if (exists(".Random.seed", envir = globalenv()))
      rm(.Random.seed, envir = globalenv())
    seed <- round(runif(1, 1, .Machine$integer.max))
  }

  withr::with_seed(seed, {

    for (j in seq_len(t)) {
      for (i in 1:num) {

        state <- chain.states[j, i]

        # ---- X ----
        if (density.X == "MVN") {

          X[, , i, j] <-
            LaplacesDemon::rmatrixnorm(
              M = M[, , state],
              U = U.X[, , state],
              V = V.X[, , state]
            )

        } else if (density.X == "MVT") {

          X[, , i, j] <- matrix(
            rTMV(
              n = 1,
              M = M[, , state],
              U = U.X[, , state],
              V = V.X[, , state],
              nu = nu.X[state]
            ),
            nrow = row.X,
            ncol = col.X
          )

        } else if (density.X == "MVCN") {

          good.X[i, j] <- stats::rbinom(1, 1, alpha.X[state])

          U_curr <- if (good.X[i, j] == 1)
            U.X[, , state]
          else
            eta.X[state] * U.X[, , state]

          X[, , i, j] <-
            LaplacesDemon::rmatrixnorm(
              M = M[, , state],
              U = U_curr,
              V = V.X[, , state]
            )
        }

        X1 <- rbind(rep(1, col.X), X[, , i, j])
        Mean_Y <- B[, , state] %*% X1

        # ---- Y ----
        if (density.Y == "MVN") {

          Y[, , i, j] <- Mean_Y +
            LaplacesDemon::rmatrixnorm(
              M = matrix(0, row.Y, col.Y),
              U = U.Y[, , state],
              V = V.Y[, , state]
            )

        } else if (density.Y == "MVT") {

          Y[, , i, j] <- Mean_Y +
            matrix(
              rTMV(
                n = 1,
                M = matrix(0, row.Y, col.Y),
                U = U.Y[, , state],
                V = V.Y[, , state],
                nu = nu.Y[state]
              ),
              nrow = row.Y,
              ncol = col.Y
            )

        } else if (density.Y == "MVCN") {

          good.Y[i, j] <- stats::rbinom(1, 1, alpha.Y[state])

          U_curr_Y <- if (good.Y[i, j] == 1)
            U.Y[, , state]
          else
            eta.Y[state] * U.Y[, , state]

          Y[, , i, j] <- Mean_Y +
            LaplacesDemon::rmatrixnorm(
              M = matrix(0, row.Y, col.Y),
              U = U_curr_Y,
              V = V.Y[, , state]
            )
        }
      }
    }
  })

  chain.states <- t(chain.states)
  colnames(chain.states) <- paste("time", 1:t, sep = " ")

  res <- list(Y = Y, X = X, obs.states = chain.states)

  if (density.X == "MVCN") res$pgood.X <- good.X
  if (density.Y == "MVCN") res$pgood.Y <- good.Y

  return(res)
}
