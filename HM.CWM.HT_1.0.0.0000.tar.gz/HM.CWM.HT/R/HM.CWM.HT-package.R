## usethis namespace: start
#' @useDynLib HM.CWM.HT, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
