#' Selection of the best fitting model(s) for both families of parsimonious models.
#'
#' This functions extracts the best fitting model(s) according to the Bayesian information criterion (BIC).
#'
#' @param results The output of the \code{HMCWMHT_fit()} function.
#' @param top Integer. Specifies the number of top-ranked models to display based on the Bayesian Information Criterion (BIC).
#' @param threshold Specifies the minimum percentage of observations required to be in each state at each time.
#' A value of 0 turns off this constraint.
#'
#' @return A list containing the required best fitting model(s), the number of disgarded models, and the number of total models.
#' @export
#' @importFrom foreach %dopar%
extract.bestM_X_Y <- function(results, top=1, threshold = 0.01) {

  k <- length(results[["results"]])
  num.mod <- length(results[["results"]][[1]][[1]])
  list.mod <- results[["models"]]
  list.mod2 <- do.call("rbind", replicate(k, list.mod, simplify = FALSE))
  count.k <- sort(rep(1:k, num.mod))
  count.mod <- rep(1:num.mod, k)
  list.mod3 <- data.frame(list.mod2, count.k, count.mod)

  allBIC <- numeric(k * num.mod)

  cont <- 0
  count.discarded <- 0 # Inizializziamo il contatore

  # Supponiamo di conoscere il numero di stati attesi (es. S)
  # Se non lo sai a priori, potresti doverlo estrarre da un parametro del modello
  # S <- current_model$nstates

  for (j in 1:k) {
    for (i in 1:num.mod) {
      cont <- cont + 1
      current_model <- results[["results"]][[j]][[1]][[i]]

      # Verifica base
      if (is.list(current_model) && "mark" %in% names(current_model) && current_model[["mark"]] == 0) {

        class_mat <- current_model[["class"]]
        S <- ncol(current_model$PI) # O il parametro che definisce gli stati
        stati_attesi <- 1:S

        is_valid <- TRUE
        for(t_idx in 1:ncol(class_mat)) {
          tab <- table(factor(class_mat[, t_idx], levels = stati_attesi))
          prop <- tab / nrow(class_mat)
          if(any(prop < threshold)) {
            is_valid <- FALSE
            break
          }
        }

        if (is_valid) {
          if ("BIC" %in% names(current_model)) {
            allBIC[cont] <- -current_model[["BIC"]]
          } else {
            allBIC[cont] <- NA
          }
        } else {
          allBIC[cont] <- NA
          count.discarded <- count.discarded + 1 # Incremento se scartato
        }
      } else {
        allBIC[cont] <- NA
        if (is.list(current_model) && "mark" %in% names(current_model)) {
          count.discarded <- count.discarded + 1
        }
      }
    }
  }
  topBIC <- which(allBIC>=sort(allBIC, decreasing = TRUE)[top])
  topBIC.order <- order(allBIC[topBIC], decreasing = TRUE)
  tempBIC <- list.mod3[topBIC[topBIC.order], ]
  bestBIC <- vector(mode = "list", length = top)
  for (i in 1:top) {
    bestBIC[[i]] <- results[["results"]][[as.numeric(tempBIC[i,5])]][[1]][[as.numeric(tempBIC[i,6])]]
  }

  return(list(
    bestBIC = bestBIC,
    discarded_count = count.discarded,
    total_checked = cont
  ))

}
