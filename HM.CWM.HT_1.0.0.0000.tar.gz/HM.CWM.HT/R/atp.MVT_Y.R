#' Atypical Detection Points Using Matrix-Variate t CWHMMs (responses)
#'
#' Detects atypical matrices on the responses via matrix-variate t CWHMMs given a specified value of \code{epsilon}.
#'
#' @param Y An array with dimensions \code{p} x \code{r} x \code{num} x \code{t}, where \code{p} is the number of
#'     variables in the rows of each data matrix, \code{r} is the number of variables in the columns of each
#'     data matrix, \code{num} is the number of data observations, and \code{t} is the number of time points.
#' @param X An array with dimensions \code{q} x \code{r} x \code{num} x \code{t}, where \code{q} is the number of
#'     variables in the rows of each data matrix, \code{r} is the number of variables in the columns of each
#'     data matrix, \code{num} is the number of data observations, and \code{t} is the number of time points.
#' @param coeff An array with dimensions \code{p} x \code{q+1} x \code{k}, where \code{k} is the number of states, containing the regression coefficient matrices.
#' @param U An array with dimensions \code{p} x \code{p} x \code{k}, where \code{k} is the number of states, containing the row covariance (scale) matrices.
#' @param V An array with dimensions \code{r} x \code{r} x \code{k}, where \code{k} is the number of states, containing the column covariance (scale) matrices.
#' @param class An \code{num} x \code{t} matrix containing the state memberships.
#' @param epsilon A numeric value specifying the selected percentile of the chi-squared distribution with \code{pr} degrees of freedom.
#'
#' @return An \code{num} x \code{t} matrix containing, for each observation and time, a 0 if it that matrix is typical and 1 otherwise.
#' @export
atp.MVT_Y <- function(Y, X, coeff, U, V, class, epsilon) {
  tr <- function(x) {
    return(sum(diag(x)))
  }

  p <- dim(Y)[1]
  r <- dim(Y)[2]
  num <- dim(Y)[3]
  t <- dim(Y)[4]
  k <- dim(coeff)[3]
  q <- nrow(X) + 1

  Yresh <- array(Y, dim = c(p, r, num * t))
  Xresh <- array(X, dim = c(q - 1, r, num* t))

  # Add intercept to X

  unos <- rep(1, r)
  X1resh <- array(0, dim = c(q, r, (num * t)))
  for (i in 1:(num * t)) {
    X1resh[, , i] <- rbind(unos, Xresh[, , i])
  }
  deltas <- matrix(NA, nrow = num * t, ncol = k)

  for (j in 1:k) {
    deltas[, j] <- sapply(1:(num * t), function(l) tr(solve(U[, , j]) %*% (Yresh[, , l] - coeff[, , j]%*%X1resh[,,l]) %*% solve(V[, , j]) %*% t(Yresh[, , l] - coeff[, , j]%*%X1resh[,,l])))
  }

  innerT <- numeric(num * t)

  for (j in 1:(num * t)) {
    innerT[j] <- ifelse((1 - stats::pchisq(deltas[j, class[j]], df = p * r)) < (1 - epsilon), 1, 0) # 1 is atypical, 0 is typical
  }

  innerT2 <- matrix(innerT, num, t)

  return(atp = innerT2)
}
