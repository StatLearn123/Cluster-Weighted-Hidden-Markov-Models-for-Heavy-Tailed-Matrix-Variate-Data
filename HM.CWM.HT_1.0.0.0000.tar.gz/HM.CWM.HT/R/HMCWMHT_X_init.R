#' Initialization for ECM Algorithms in Matrix-Variate Hidden Markov Cluster-Weighted Models with heavy tails and parsimony on X.
#'
#' Initializes the ECM algorithms used for fitting matrix-variate Hidden Markov Cluster-Weighted Models with heavy tails and parsimony on X.
#' Parallel computing is implemented and highly recommended for faster computations.
#'
#' @param Y An array with dimensions \code{p} x \code{r} x \code{num} x \code{t}, where \code{p} is the number of
#'     responses, \code{r} is the number of occasions, \code{num} is the number of data observations,
#'      and \code{t} is the number of time points.
#' @param X An array with dimensions \code{q} x \code{r} x \code{num} x \code{t}, where \code{q} is the number of
#'     covariates, \code{r} is the number of occasions, \code{num} is the number of data observations,
#'      and \code{t} is the number of time points.
#' @param k An integer or vector indicating the number of states in the model(s).
#' @param densityY A character string specifying the distribution to use for the responses.
#'                Possible values are: "MVN" for the matrix-variate normal distribution,
#'                "MVT" for the matrix-variate t-distribution, "MVCN" for the matrix-variate contaminated normal distribution,
#'                and "all" for both heavy-tailed distributions.
#' @param densityX A character string specifying the distribution to use for the covariates.
#'                Possible values are: "MVN" for the matrix-variate normal distribution,
#'                "MVT" for the matrix-variate t-distribution, "MVCN" for the matrix-variate contaminated normal distribution,
#'                and "all" for both heavy-tailed distributions.
#' @param mod.row.X A character string indicating the parsimonious structure of the row covariance (or scale) matrices.
#'                Possible values are: "EII", "VII", "EEI", "VEI", "EVI", "VVI", "EEE", "VEE", "EVE", "EEV", "VVE", "VEV", "EVV", "VVV", or "all".
#'                When "all" is specified, all 14 parsimonious structures are considered.
#' @param mod.col.X A character string indicating the parsimonious structure of the column covariance (or scale) matrices.
#'                Possible values are: "II", "EI", "VI", "EE", "VE", "EV", "VV", or "all".
#'                When "all" is specified, all 7 parsimonious structures are considered.
#' @param nstartR An integer specifying the number of random starts to consider.
#' @param nThreads A positive integer indicating the number of cores to use for parallel processing.
#' @param verbose A logical value indicating whether to display the running output.
#' @param seed A positive integer specifying the seed for random generation.
#'
#' @return A list containing the following elements:
#' \item{results}{A list of the results from the initialization.}
#' \item{k}{The number of states fitted in each model.}
#' \item{dens}{The density used for the HMMs.}
#' @export
#' @useDynLib HM.CWM.HT, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom foreach %dopar%
HMCWMHT_X_init <- function(Y, X, k, densityY, densityX, mod.row.X = "all", mod.col.X = "all", nstartR = 50, nThreads = 1, verbose = FALSE, seed = 1) {
  r_Pars_init <- function(Y, X, k, densityY, densityX, mod.row.X = "all", mod.col.X = "all", nstartR = 50, seed = NULL) {

    tr <- function(x) {
      return(sum(diag(x)))
    }
    transit <- function(Y) {
      # Y is a matrix N \times T

      N <- dim(Y)[1]
      T <- dim(Y)[2]
      K <- max(Y)

      if (K == 1) {
        PI <- matrix(1, 1, 1)
      }

      if (K > 1) {
        PI <- matrix(0, nrow = K, ncol = K)

        for (i in 1:N) {
          for (t in 2:T) {
            PI[Y[i, t - 1], Y[i, t]] <- PI[Y[i, t - 1], Y[i, t]] + 1
          }
        }
        PI <- diag(1 / rowSums(PI)) %*% PI
      }

      return(PI)
    }

    # Dimensions

    num0 <- dim(Y)[3]
    p <- nrow(Y)
    r <- ncol(Y)
    t <- dim(Y)[4]
    q <- nrow(X) + 1

    num <- num0 * t
    Yresh <- array(Y, dim = c(p, r, num))
    Xresh <- array(X, dim = c(q - 1, r, num))

    # Add intercept to X

    unos <- rep(1, r)
    X1resh <- array(0, dim = c(q, r, num))
    for (i in 1:num) {
      X1resh[, , i] <- rbind(unos, Xresh[, , i])
    }

    XY <- array(0, dim = c((p + q - 1), r, num))

    for (i in 1:num) {
      XY[, , i] <- rbind(Yresh[, , i], Xresh[, , i])
    }

    # Create some objects

    prior <- matrix(NA, nstartR, k)
    llk <- rep(NA, nstartR)

    coeff <- array(0, dim = c(p, q, k, nstartR))
    M <- array(0, dim = c(q - 1, r, k, nstartR))

    WRY <- array(0, dim = c(p, p, k, nstartR))
    WCY <- array(0, dim = c(r, r, k, nstartR))
    WRX <- array(0, dim = c(q - 1, q - 1, k, nstartR))
    WCX <- array(0, dim = c(r, r, k, nstartR))

    sigmaUY <- array(0, dim = c(p, p, k, nstartR))
    sigmaVY <- array(0, dim = c(r, r, k, nstartR))
    sigmaUX <- array(0, dim = c((q - 1), (q - 1), k, nstartR))
    sigmaVX <- array(0, dim = c(r, r, k, nstartR))

    sel <- array(0, dim = c(p + q - 1, r, k))
    dens <- array(0, c(num, k), dimnames = list(1:(num), paste("comp.", 1:k, sep = "")))
    post2 <- array(NA, c(k, k, num0, t - 1)) # transition probabilities
    f <- array(NA, c(num0, t, k, nstartR))
    A <- B <- array(NA, c(num0, t, k, nstartR))
    PI <- array(NA, dim = c(k, k, nstartR))

    nuY <- alphaY <- etaY <- nuX <- alphaX <- etaX <- rep(0, k)

    if (densityY == "MVT") {
      nuY <- rep(30, k)
    } else if (densityY == "MVCN") {
      alphaY <- rep(0.99, k)
      etaY <- rep(1.01, k)
    }
    if (densityX == "MVT") {
      nuX <- rep(30, k)
    } else if (densityX == "MVCN") {
      alphaX <- rep(0.99, k)
      etaX <- rep(1.01, k)
    }

    ## Random initialization ##

    eu <- matrix(0, nrow = num, ncol = k)
    classy <- numeric(num)
    rand.start <- matrix(0, nstartR, k)

    withr::with_seed(seed, for (i in 1:nstartR) {
      rand.start[i, ] <- sample(c(1:num), k)
    })

    evs <- numeric(nstartR)

    for (h in 1:nstartR) {
      skip_to_next <- FALSE

      ### part 0 ###

      tryCatch(
        {
          sec <- rand.start[h, ]

          for (j in 1:k) {
            sel[, , j] <- XY[, , sec[j]]
          }

          for (j in 1:k) {
            for (i in 1:num) {
              eu[i, j] <- norm((XY[, , i] - sel[, , j]), type = "F")
            }
          }

          for (i in 1:(num)) {
            classy[i] <- which.min(eu[i, ])
          }

          z <- mclust::unmap(classy)

          ### part 1 ###

          # Regression Coefficients + Partial U & V #

          for (j in 1:k) {

            # Yresh #

            tempcoeff1 <- tensor::tensor(aperm(tensor::tensor(Yresh * z[, j][slice.index(Yresh, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm(X1resh, c(2, 1, 3)), c(2, 3), c(1, 3))
            tempcoeff2 <- tensor::tensor(aperm(tensor::tensor(X1resh * z[, j][slice.index(X1resh, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm(X1resh, c(2, 1, 3)), c(2, 3), c(1, 3))

            coeff[, , j, h] <- tempcoeff1 %*% solve(tempcoeff2)

            BX <- tensor::tensor(coeff[, , j, h], X1resh, 2, 1)

            WRY[, , j, h] <- tensor::tensor(aperm(tensor::tensor((Yresh - BX) * z[, j][slice.index(Yresh - BX, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm((Yresh - BX), c(2, 1, 3)), c(2, 3), c(1, 3))
            sigmaUY[, , j, h] <- WRY[, , j, h] / (r * sum(z[, j]))

            WCY[, , j, h] <- tensor::tensor(aperm(tensor::tensor(aperm(Yresh - BX, c(2, 1, 3)) * z[, j][slice.index(aperm(Yresh - BX, c(2, 1, 3)), 3)], solve(sigmaUY[, , j, h]), 2, 1), c(1, 3, 2)), (Yresh - BX), c(2, 3), c(1, 3))
            sigmaVY[, , j, h] <- WCY[, , j, h] / (p * sum(z[, j]))

            # Xresh #

            M[, , j, h] <- rowSums(Xresh * z[, j][slice.index(Xresh, 3)], dims = 2) / sum(z[, j])
            Mtemp <- array(M[, , j, h], dim = c(q - 1, r, num))

            WRX[, , j, h] <- tensor::tensor(aperm(tensor::tensor((Xresh - Mtemp) * z[, j][slice.index(Xresh - Mtemp, 3)], diag(r), 2, 1), c(1, 3, 2)), aperm((Xresh - Mtemp), c(2, 1, 3)), c(2, 3), c(1, 3))
            WCX[, , j, h] <- tensor::tensor(aperm(tensor::tensor(aperm(Xresh - Mtemp, c(2, 1, 3)) * z[, j][slice.index(aperm(Xresh - Mtemp, c(2, 1, 3)), 3)], solve(WRX[, , j, h]), 2, 1), c(1, 3, 2)), (Xresh - Mtemp), c(2, 3), c(1, 3))

          }

          # Row covariance matrix X #

          if (mod.row.X == "EII") {
            if (k == 1) {
              phiX <- tr(WRX[, , , h]) / ((num) * (q - 1) * r)
            } else {
              phiX <- tr(rowSums(WRX[, , , h], dims = 2)) / ((num) * (q - 1) * r)
            }

            for (j in 1:k) {
              sigmaUX[, , j, h] <- phiX * diag(1, q - 1, q - 1)
            }
          }

          if (mod.row.X == "EEI") {
            if (k == 1) {
              deltaUX <- diag(diag(WRX[, , , h]), q - 1, q - 1) / (det(diag(diag(WRX[, , , h]), q - 1, q - 1)))^(1 / (q - 1))

              phiX <- (det(diag(diag(WRX[, , , h]), q - 1, q - 1)))^(1 / (q - 1)) / ((num) * r)
            } else {
              deltaUX <- diag(diag(rowSums(WRX[, , , h], dims = 2)), q - 1, q - 1) / (det(diag(diag(rowSums(WRX[, , , h], dims = 2)), q - 1, q - 1)))^(1 / (q - 1))

              phiX <- (det(diag(diag(rowSums(WRX[, , , h], dims = 2)), q - 1, q - 1)))^(1 / (q - 1)) / ((num) * r)
            }

            for (j in 1:k) {
              sigmaUX[, , j, h] <- phiX * deltaUX
            }
          }

          if (mod.row.X == "EEE") {
            if (k == 1) {
              sigmaUX[, , 1, h] <- WRX[, , , h] / (num * r)
            } else {
              for (j in 1:k) {
                sigmaUX[, , j, h] <- rowSums(WRX[, , , h], dims = 2) / (num * r)
              }
            }
          }

          # Column covariance matrix X #

          if (mod.col.X == "II") {
            for (j in 1:k) {
              sigmaVX[, , j, h] <- diag(1, r, r)
            }
          }

          if (mod.col.X == "EI") {
            if (k == 1) {
              deltaVX <- diag(diag(WCX[, , , h]), r, r) / (det(diag(diag(WCX[, , , h]), r, r)))^(1 / r)
            } else {
              deltaVX <- diag(diag(rowSums(WCX[, , , h], dims = 2)), r, r) / (det(diag(diag(rowSums(WCX[, , , h], dims = 2)), r, r)))^(1 / r)
            }

            for (j in 1:k) {
              sigmaVX[, , j, h] <- deltaVX
            }
          }

          if (mod.col.X == "EE") {
            if (k == 1) {
              sigmaVX[, , 1, h] <- WCX[, , , h] / (det(WCX[, , , h]))^(1 / r)
            } else {
              for (j in 1:k) {
                sigmaVX[, , j, h] <- rowSums(WCX[, , , h], dims = 2) / ((det(rowSums(WCX[, , , h], dims = 2)))^(1 / r))
              }
            }
          }

          # Density computation #

          for (j in 1:k) {

            # 1. Calcolo globale della densità per X
            if (densityX == "MVN") {
              p_X <- as.vector(dMVnorm(X = Xresh, M = M[, , j, h], U = sigmaUX[, , j, h], V = sigmaVX[, , j, h]))
            } else if (densityX == "MVT") {
              p_X <- as.vector(dMVT(X = Xresh, M = M[, , j, h], U = sigmaUX[, , j, h], V = sigmaVX[, , j, h], nu = nuX[j]))
            } else if (densityX == "MVCN") {
              p_X <- as.vector(dMVcont(X = Xresh, M = M[, , j, h], U = sigmaUX[, , j, h], V = sigmaVX[, , j, h], alpha = alphaX[j], eta = etaX[j]))
            }

            # 2. Calcolo punto per punto per Y e combinazione con X
            for (i in 1:num) {
              if (densityY == "MVN") {
                p_Y <- as.vector(dMVnorm(X = Yresh[, , i], M = coeff[, , j, h] %*% X1resh[, , i], U = sigmaUY[, , j, h], V = sigmaVY[, , j, h]))
              } else if (densityY == "MVT") {
                p_Y <- as.vector(dMVT(X = Yresh[, , i], M = coeff[, , j, h] %*% X1resh[, , i], U = sigmaUY[, , j, h], V = sigmaVY[, , j, h], nu = nuY[j]))
              } else if (densityY == "MVCN") {
                p_Y <- as.vector(dMVcont(X = Yresh[, , i], M = coeff[, , j, h] %*% X1resh[, , i], U = sigmaUY[, , j, h], V = sigmaVY[, , j, h], alpha = alphaY[j], eta = etaY[j]))
              }

              # Densità congiunta: p_Y (scalare) * p_X[i] (l'i-esimo elemento del vettore di X)
              dens[i, j] <- p_Y * p_X[i]
            }
          }

          if (k == 1) {
            prior[h, ] <- 1
          } else {
            prior[h, ] <- colMeans(z)
          }

          ### part 2 - in log appraoch to prevent underflow ###

          f[, , , h] <- array(dens, c(num0, t, k))

          PI[, , h] <- transit(matrix(classy, num0, t))

          foo <- matrix(rep(prior[h, ], each = num0), ncol = k) * f[, 1, , h]
          sumfoo <- rowSums(foo)
          lscale <- log(sumfoo)
          foo <- foo / sumfoo
          A[, 1, , h] <- lscale + log(foo) # lalpha [ ,1]

          for (T in 2:t) {
            foo <- foo %*% PI[, , h] * f[, T, , h]
            sumfoo <- rowSums(foo)
            lscale <- lscale + log(sumfoo)
            foo <- foo / sumfoo
            A[, T, , h] <- log(foo) + lscale
          }

          llk[h] <- sum(lscale) # log-likelihood

          B[, t, , h] <- 0

          foo <- matrix(rep(rep(1 / k, k), each = num0), ncol = k)
          lscale <- log(k)

          for (T in (t - 1):1) {
            foo <- t(PI[, , h] %*% t(foo * f[, T + 1, , h]))
            B[, T, , h] <- log(foo) + lscale
            sumfoo <- rowSums(foo)
            foo <- foo / sumfoo
            lscale <- lscale + log(sumfoo)
          }

          if (any(is.infinite(A[, , , h]))) {
            llk[h] <- NA
          }
          if (any(is.infinite(B[, , , h]))) {
            llk[h] <- NA
          }
        },
        error = function(e) {
          skip_to_next <<- TRUE
        }
      )

      if (skip_to_next) {
        next
      }
    }

    if (all(evs == 1) == FALSE) {
      llk[evs == 1] <- NA
    }

    df <- data.frame(llk = llk, pos = c(1:nstartR))
    df <- tidyr::drop_na(df)
    df <- df[!is.infinite(rowSums(df)), ]
    bestR <- utils::head(data.table::setorderv(df, cols = "llk", order = -1), n = 1)$pos

    CF <- array(coeff[, , , bestR], dim = c(p, q, k))
    sigmaUY <- array(sigmaUY[, , , bestR], dim = c(p, p, k))
    sigmaVY <- array(sigmaVY[, , , bestR], dim = c(r, r, k))
    MX <- array(M[, , , bestR], dim = c(q - 1, r, k))
    sigmaUX <- array(sigmaUX[, , , bestR], dim = c(q - 1, q - 1, k))
    sigmaVX <- array(sigmaVX[, , , bestR], dim = c(r, r, k))

    PI2 <- matrix(PI[, , bestR], k, k)
    ef <- array(f[, , , bestR], c(num0, t, k))
    a <- array(A[, , , bestR], c(num0, t, k))
    b <- array(B[, , , bestR], c(num0, t, k))
    lik <- llk[bestR]

    return(list(
      densY = densityY, densX = densityX, model = c(mod.row.X, mod.col.X), prior = prior[bestR, ],
      coeff = CF, sigmaUY = sigmaUY, sigmaVY = sigmaVY,
      nuY = nuY, alphaY = alphaY, etaY = etaY,
      M = MX, sigmaUX = sigmaUX, sigmaVX = sigmaVX,
      nuX = nuX, alphaX = alphaX, etaX = etaX,
      PI = PI2, f = ef, A = a, B = b, llk = lik
    ))
  }

  comb <- function(x, ...) {
    lapply(
      seq_along(x),
      function(i) c(x[[i]], lapply(list(...), function(y) y[[i]]))
    )
  }

  if (any(mod.row.X == "all")) {
    mod.row.X.i <- c("EII", "VII", "EEI", "VEI", "EVI", "VVI", "EEE", "VEE", "EVE", "VVE", "EEV", "VEV", "EVV", "VVV")
  } else {
    mod.row.X.i <- mod.row.X
  }
  if (any(mod.col.X == "all")) {
    mod.col.X.i <- c("II", "EI", "VI", "EE", "VE", "EV", "VV")
  } else {
    mod.col.X.i <- mod.col.X
  }

  if (any(densityY == "all")) {
    densityY.i <- c("MVT","MVCN")
  } else {
    densityY.i <- densityY
  }
  if (any(densityX == "all")) {
    densityX.i <- c("MVT","MVCN")
  } else {
    densityX.i <- densityX
  }

  req.model <- expand.grid(mod.row.X.i, mod.col.X.i,densityY.i,densityX.i)
  names(req.model) <- paste(rep("V", each =  ncol(req.model)), 1:ncol(req.model), sep = "")

  nest.EII.X <- c("EII", "VII")
  nest.EEI.X <- c("EEI", "VEI", "EVI", "VVI")
  nest.EEE.X <- c("EEE", "VEE", "EVE", "EEV", "VVE", "VEV", "EVV", "VVV")
  nest.II.X <- c("II")
  nest.EI.X <- c("EI", "VI")
  nest.EE.X <- c("EE", "VE", "EV", "VV")

  list.comb <- data.frame(matrix(NA, nrow = nrow(req.model), ncol = 4))
  list.comb[, 3] <- req.model[, 3]
  list.comb[, 4] <- req.model[, 4]

  list.comb[, 1] <- ifelse(req.model[, 1] %in% nest.EII.X, "EII",
                           ifelse(req.model[, 1] %in% nest.EEI.X, "EEI",
                                  ifelse(req.model[, 1] %in% nest.EEE.X, "EEE", NA)))

  list.comb[, 2] <- ifelse(req.model[, 2] %in% nest.II.X, "II",
                           ifelse(req.model[, 2] %in% nest.EI.X, "EI",
                                  ifelse(req.model[, 2] %in% nest.EE.X, "EE", NA)))
  list.comb2 <- unique(list.comb)

  oper <- vector(mode = "list", length = length(k))
  time <- numeric(length(k))

  for (g in 1:length(k)) {
    ptm <- proc.time()

    if (verbose == TRUE) {
      cat(paste0(
        "Initializing HM-CWM-HT_X [Y: ", densityY, " | X: ", densityX, "] ",
        "with k = ", k[g], "\n"
      ))    }

    cluster <- snow::makeCluster(nThreads, type = "SOCK")
    doSNOW::registerDoSNOW(cluster)

    pb <- progress::progress_bar$new(
      format = "(:spin) [:bar] :percent [Elapsed time: :elapsedfull || Estimated time remaining: :eta]",
      total = nrow(list.comb2),
      complete = "=", # Completion bar character
      incomplete = "-", # Incomplete bar character
      current = ">", # Current bar character
      width = 100
    )
    progress <- function(n) {
      pb$tick()
    }
    opts <- list(progress = progress)

    l <- 0

    oper[[g]] <- foreach::foreach(l = 1:nrow(list.comb2), .combine = "comb", .multicombine = TRUE, .init = list(list()), .options.snow = opts) %dopar% {
      res <- r_Pars_init(
        Y = Y, X = X, k = k[g], densityY = as.character(list.comb2[l, 3]), densityX = as.character(list.comb2[l, 4]),
        mod.row.X = list.comb2[l, 1], mod.col.X = list.comb2[l, 2],
        nstartR = nstartR, seed = seed
      )

      list(res)
    }

    snow::stopCluster(cluster)
    foreach::registerDoSEQ()

    ptm2 <- proc.time() - ptm
    time[g] <- ptm2[3]
  }

  keys_comb <- apply(list.comb, 1, paste, collapse = "_")

  keys_oper <- sapply(1:nrow(list.comb2), function(j) {
    model_part <- paste(oper[[1]][[1]][[j]][["model"]], collapse = "_")
    dens_part <- paste(c(oper[[1]][[1]][[j]][["densY"]],oper[[1]][[1]][[j]][["densX"]]), collapse = "_")
    risultato <- paste(model_part, dens_part, sep = "_")
    risultato
  })

  res_vector <- match(keys_comb, keys_oper)

  return(list(
    results = oper,
    k = k,
    req.model = req.model,
    init.used = list.comb,
    index = res_vector,
    densY = densityY.i,
    densX = densityX.i,
    c.time = time
  ))
} # initializing function
