#include <RcppArmadillo.h>
using namespace Rcpp;

// [[Rcpp::depends(RcppArmadillo)]]

// =============================================================================
// 1. MATRIX-VARIATE NORMAL DENSITY
// =============================================================================
// [[Rcpp::export]]
SEXP dMVnorm(const SEXP& X, const arma::mat& M, const arma::mat& U, const arma::mat& V) {
    arma::mat U_inv = arma::inv(U);
    arma::mat V_inv = arma::inv(V);
    
    // If input is a matrix (single point)
    if (Rf_isMatrix(X)) {
        arma::mat X_mat = as<arma::mat>(X);
        arma::mat X_diff = X_mat - M;
        double delta = arma::as_scalar(arma::trace(U_inv * X_diff * V_inv * X_diff.t()));
        
        double const_term = std::pow(2 * M_PI, -0.5 * X_mat.n_rows * X_mat.n_cols) * std::pow(arma::det(U), -0.5 * X_mat.n_cols) * std::pow(arma::det(V), -0.5 * X_mat.n_rows);
        
        double pdf = const_term * std::exp(-0.5 * delta);
        return wrap(pdf);  // Return single density value (double)
        
    // If input is a 3D array (multiple points)
    } else if (Rf_isArray(X)) {
        arma::cube X_cube = as<arma::cube>(X);
        int num = X_cube.n_slices;
        int p = X_cube.n_rows;
        int r = X_cube.n_cols;
        arma::vec delta(num);
        
        for (int i = 0; i < num; ++i) {
            arma::mat X_diff = X_cube.slice(i) - M;
            delta(i) = arma::as_scalar(arma::trace(U_inv * X_diff * V_inv * X_diff.t()));
        }
        
        double const_term = std::pow(2 * M_PI, -0.5 * p * r) * std::pow(arma::det(U), -0.5 * r) * std::pow(arma::det(V), -0.5 * p);
        
        arma::vec pdf = const_term * arma::exp(-0.5 * delta);
        return wrap(pdf);  // Return vector of density values (arma::vec)
    }

    return R_NilValue;
}

// =============================================================================
// 2. MATRIX-VARIATE STUDENT-T DENSITY
// =============================================================================
// [[Rcpp::export]]
SEXP dMVT(const SEXP& X, const arma::mat& M, const arma::mat& U, const arma::mat& V, double nu) {
    arma::mat U_inv = arma::inv(U);
    arma::mat V_inv = arma::inv(V);
    
    // If input is a matrix (single point)
    if (Rf_isMatrix(X)) {
        arma::mat X_mat = as<arma::mat>(X);
        int p = X_mat.n_rows;
        int r = X_mat.n_cols;
        
        arma::mat X_diff = X_mat - M;
        double delta = arma::as_scalar(arma::trace(U_inv * X_diff * V_inv * X_diff.t()));
        
        double pdfconst = (std::pow(arma::det(U), -0.5 * r) * std::pow(arma::det(V), -0.5 * p) * std::tgamma(0.5 * ((p * r) + nu))) / 
                          (std::pow(M_PI * nu, 0.5 * p * r) * std::tgamma(nu * 0.5));
        double pdfvar = std::pow(1.0 + delta / nu, -0.5 * ((p * r) + nu));
        
        double pdf = pdfconst * pdfvar;
        return wrap(pdf);
        
    // If input is a 3D array (multiple points)
    } else if (Rf_isArray(X)) {
        arma::cube X_cube = as<arma::cube>(X);
        int num = X_cube.n_slices;
        int p = X_cube.n_rows;
        int r = X_cube.n_cols;
        arma::vec delta(num);
        
        for (int i = 0; i < num; ++i) {
            arma::mat X_diff = X_cube.slice(i) - M;
            delta(i) = arma::as_scalar(arma::trace(U_inv * X_diff * V_inv * X_diff.t()));
        }
        
        double pdfconst = (std::pow(arma::det(U), -0.5 * r) * std::pow(arma::det(V), -0.5 * p) * std::tgamma(0.5 * ((p * r) + nu))) / 
                          (std::pow(M_PI * nu, 0.5 * p * r) * std::tgamma(nu * 0.5));
        arma::vec pdfvar = arma::pow(1.0 + delta / nu, -0.5 * ((p * r) + nu));
        
        arma::vec pdf = pdfconst * pdfvar;
        return wrap(pdf);
    }
    
    return R_NilValue;
}

// =============================================================================
// 3. MATRIX-VARIATE CONTAMINATED NORMAL DENSITY
// =============================================================================
// [[Rcpp::export]]
SEXP dMVcont(const SEXP& X, const arma::mat& M, const arma::mat& U, const arma::mat& V, double alpha, double eta) {
    arma::mat U_inv = arma::inv(U);
    arma::mat V_inv = arma::inv(V);
    
    // If input is a matrix (single point)
    if (Rf_isMatrix(X)) {
        arma::mat X_mat = as<arma::mat>(X);
        int p = X_mat.n_rows;
        int r = X_mat.n_cols;
        
        arma::mat X_diff = X_mat - M;
        double delta = arma::as_scalar(arma::trace(U_inv * X_diff * V_inv * X_diff.t()));
        
        double common_det = std::pow(arma::det(U), -0.5 * r) * std::pow(arma::det(V), -0.5 * p);
        
        double pdf_good = std::pow(2 * M_PI, -0.5 * p * r) * common_det * std::exp(-0.5 * delta);
        double pdf_bad = std::pow(2 * M_PI, -0.5 * p * r) * std::pow(eta, -0.5 * p * r) * common_det * std::exp(-0.5 * (delta / eta));
        
        double pdf = alpha * pdf_good + (1.0 - alpha) * pdf_bad;
        return wrap(pdf);
        
    // If input is a 3D array (multiple points)
    } else if (Rf_isArray(X)) {
        arma::cube X_cube = as<arma::cube>(X);
        int num = X_cube.n_slices;
        int p = X_cube.n_rows;
        int r = X_cube.n_cols;
        arma::vec delta(num);
        
        for (int i = 0; i < num; ++i) {
            arma::mat X_diff = X_cube.slice(i) - M;
            delta(i) = arma::as_scalar(arma::trace(U_inv * X_diff * V_inv * X_diff.t()));
        }
        
        double common_det = std::pow(arma::det(U), -0.5 * r) * std::pow(arma::det(V), -0.5 * p);
        
        arma::vec pdf_good = std::pow(2 * M_PI, -0.5 * p * r) * common_det * arma::exp(-0.5 * delta);
        arma::vec pdf_bad = std::pow(2 * M_PI, -0.5 * p * r) * std::pow(eta, -0.5 * p * r) * common_det * arma::exp(-0.5 * (delta / eta));
        
        arma::vec pdf = alpha * pdf_good + (1.0 - alpha) * pdf_bad;
        return wrap(pdf);
    }
    
    return R_NilValue;
}
